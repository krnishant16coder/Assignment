package com.chatlog.assignment.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.chatlog.assignment.modal.ChatLog;
import com.chatlog.assignment.repository.ChatRepository;

@Service
public class ChatService {
	
	@Autowired
	ChatRepository chatRepository;
	
	public String createChatLog(ChatLog chatLog){
		chatRepository.save(chatLog);
		return "ChatLog created successfully";
	}

	public ChatLog findChatById(Integer msgId) {
		Optional<ChatLog> optEmp = chatRepository.findById(msgId);
		return optEmp.get()  ;
	}
	
	public List<ChatLog> findAllChat(int pageNum) {
		Pageable pageable = PageRequest.of(0, pageNum);
		Page<ChatLog> pagedResult = chatRepository.findAll(pageable);
		return pagedResult.getContent();
	}

	public String deleteChat() {
		chatRepository.deleteAll();
		return "Message deleted Successfully";
	}
	
	public void deleteChatById(int msgId) {
		chatRepository.deleteById(msgId);
		return ;
	}
}
