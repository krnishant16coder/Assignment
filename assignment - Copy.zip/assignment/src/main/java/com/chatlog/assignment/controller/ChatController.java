package com.chatlog.assignment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.chatlog.assignment.modal.ChatLog;
import com.chatlog.assignment.service.ChatService;
import com.chatlog.assignment.service.exception.ResourceNotFoundException;

@RestController
public class ChatController {
	
	@Autowired
	ChatService chatService;
	
	@PostMapping("/createchat")
	public String createChatLog(@RequestBody ChatLog chatLog) {
		System.out.println("Create object"+chatLog.getMsgId());
		return chatService.createChatLog(chatLog);
	}
	
	@GetMapping("/getChat/{pageNum}")
	public List<ChatLog> findAllChat(@PathVariable("pageNum") int pageNum){
		System.out.println("Id is :"+pageNum);
		return chatService.findAllChat(pageNum);
	}
	
	@DeleteMapping("/delete/{msgId}")
	public String deleteChatById(@PathVariable("msgId") int msgId){
		ChatLog chatLog = chatService.findChatById(msgId);
		if(chatLog.getMsgId() == 0){
			return "Object Not found";
		} else{
			chatService.deleteChatById(msgId);
	        return "Object deleted successfully";
		}
	}
	
	@DeleteMapping
	public String deleteChat(){
		return chatService.deleteChat();
	}
	
	

}
