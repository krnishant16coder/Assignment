package com.chatlog.assignment.modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ChatLog")
public class ChatLog {

	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int msgId;
	
	private String message;

	private Long timeStamp;
	
	private int isSent;

	public int getMsgId() {
		return msgId;
	}

	public void setMsgId(int msgId) {
		this.msgId = msgId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Long getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Long timeStamp) {
		this.timeStamp = timeStamp;
	}

	public int getIsSent() {
		return isSent;
	}

	public void setIsSent(int isSent) {
		this.isSent = isSent;
	}

	public ChatLog(int msgId, String message, Long timeStamp, int isSent) {
		super();
		this.msgId = msgId;
		this.message = message;
		this.timeStamp = timeStamp;
		this.isSent = isSent;
	}

	public ChatLog() {
		super();
	}
	

}
