package com.chatlog.assignment.service.exception;

public class ResourceNotFoundException extends Exception {
	
	private int status;
	private String message;
	private int msgId;
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getMsgId() {
		return msgId;
	}
	public void setMsgId(int msgId) {
		this.msgId = msgId;
	}
	public ResourceNotFoundException(int status, String message, int msgId) {
		super();
		this.status = status;
		this.message = message;
		this.msgId = msgId;
	}
	public ResourceNotFoundException() {
		super();
	}
	
	

}
